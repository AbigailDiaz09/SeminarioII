from bacteria import bacteria
from chemiotaxis import chemiotaxis
import numpy as np

# Variables iniciales
poblacion = []
path = "C:/Users/aby92/OneDrive/Escritorio/ABIGAIL/SEMINARIO II/BacteriaForagin/secuencias/multifasta.fasta"
numeroDeBacterias = 5
numRandomBacteria = 3
iteraciones = 8
tumbo = 10
nado = 30

# Instancias principales
chemio = chemiotaxis()
veryBest = bacteria(path)
tempBacteria = bacteria(path)
original = bacteria(path)
globalNFE = 0

# Parámetros de interacción
dAttr = 0.1
wAttr = 0.2
hRep = dAttr
wRep = 10

# Funciones de clonación y validación
def clonaBest(veryBest, best):
    veryBest.matrix.seqs = np.array(best.matrix.seqs)
    veryBest.blosumScore = best.blosumScore
    veryBest.fitness = best.fitness
    veryBest.interaction = best.interaction

def validaSecuencia(path, veryBest):
    tempBacteria.matrix.seqs = np.array(veryBest.matrix.seqs)
    for i in range(len(tempBacteria.matrix.seqs)):
        tempBacteria.matrix.seqs[i] = tempBacteria.matrix.seqs[i].replace("-", "")
    for i in range(len(tempBacteria.matrix.seqs)):
        if tempBacteria.matrix.seqs[i] != original.matrix.seqs[i]:
            print("************ SECUENCIAS NO COINCIDEN ************")
            return
    
    # Inicializar la población
    for _ in range(numeroDeBacterias):
        poblacion.append(bacteria(path))
    
    # Iteraciones de forrajeo
    global globalNFE
    for _ in range(iteraciones):
        for bact in poblacion:
            bact.tumboNado(tumbo)
            bact.autoEvalua()
        chemio.doChemioTaxis(poblacion, dAttr, wAttr, hRep, wRep)
        globalNFE += chemio.parcialNFE
        
        best = max(poblacion, key=lambda x: x.fitness)
        if (veryBest.fitness == 0) or (best.fitness > veryBest.fitness):
            clonaBest(veryBest, best)
        
        print(f"Iteración: {veryBest.interaction} Fitness: {veryBest.fitness} NFE: {globalNFE}")
        chemio.eliminarClonar(path, poblacion)
        chemio.insertRandomBacterias(path, numRandomBacteria, poblacion)
        print("Población:", len(poblacion))

veryBest.showGenome()
validaSecuencia(path, veryBest)
