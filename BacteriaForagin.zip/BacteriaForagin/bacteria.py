from fastaReader import fastaReader
from evaluadorBloosum import evaluadorBloosum
import random
import numpy as np
import copy

class bacteria:
    def __init__(self, path):
        self.matrix = fastaReader(path)
        self.blosumScore = 0
        self.fitness = 0
        self.interaction = 0
        self.NFE = 0

    def showGenome(self):
        for seq in self.matrix.seqs:
            print(seq)

    def clonar(self, path):
        newBacteria = bacteria(path)
        newBacteria.matrix.seqs = np.array(copy.deepcopy(self.matrix.seqs))
        return newBacteria

    def tumboNado(self, numGaps):
        self.cuadra()
        matrixCopy = copy.deepcopy(self.matrix.seqs).tolist()
        gapRandomNumber = random.randint(0, numGaps)
        for _ in range(gapRandomNumber):
            seqnum = random.randint(0, len(matrixCopy) - 1)
            pos = random.randint(0, len(matrixCopy[0]))
            matrixCopy[seqnum] = matrixCopy[seqnum][:pos] + "-" + matrixCopy[seqnum][pos:]
        self.matrix.seqs = np.array(matrixCopy)
        self.cuadra()
        self.limpiaColumnas()  # Llamada al nuevo método para limpiar columnas de gaps

    def cuadra(self):
        seqs = self.matrix.seqs
        maxLen = len(max(seqs, key=len))
        for i in range(len(seqs)):
            if len(seqs[i]) < maxLen:
                seqs[i] = seqs[i] + "-" * (maxLen - len(seqs[i]))
        self.matrix.seqs = np.array(seqs)

    def gapColumn(self, col):
        for i in range(len(self.matrix.seqs)):
            if self.matrix.seqs[i][col] != "-":
                return False
        return True

    def limpiaColumnas(self):
        # Eliminar columnas que solo contengan gaps
        seqs = self.matrix.seqs
        seqsT = seqs.T  # Transponer la matriz para manipular columnas como filas
        filteredSeqs = [col for col in seqsT if not self.gapColumn(seqsT.tolist().index(col))]
        self.matrix.seqs = np.array(filteredSeqs).T  # Volver a transponer después de eliminar columnas de gaps

    def autoEvalua(self):
        # Supón que tienes una matriz de evaluación BLOSUM en evaluadorBloosum
        evaluador = evaluadorBloosum()
        score = 0
        for i in range(len(self.matrix.seqs) - 1):
            for j in range(i + 1, len(self.matrix.seqs)):
                score += evaluador.getScore(self.matrix.seqs[i], self.matrix.seqs[j])
        self.blosumScore = score
        self.fitness = self.blosumScore  # Se puede ajustar según los cálculos de fitness deseados




