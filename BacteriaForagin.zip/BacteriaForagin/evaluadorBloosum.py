import blosum as bl

class evaluadorBloosum:
    def __init__(self):
        self.matrix = bl.BLOSUM(62)

    def getScore(self, A, B):
        return self.matrix[A][B]
